versione='1.0.3'

import re, requests, sys, logging

PY3 = sys.version_info[0] == 3

def rsi(parIn=None):
    chName="rsilajuve"
    chRef="zzz.php"

    if parIn == "LA1":
        chName="RsiLa1Live"
        chRef="RsiLa1.php"
    source = requests.get('https://www.janjua.tv/hembedplayer/'+chName+'/3/800/456',headers={'user-agent':'Mozilla/5.0','referer':'https://easysite.one/z/Player/embed/Native/'+chRef,'accept':'*/*'}).content
    if PY3:
        source = source.decode('utf-8')
    tok,lhtml,ids = re.findall('enableVideo.[\'"]([^\'"]+)[\w\W]+?ajax..url.+?[\'"](.+?\?(\d+))',source)[0]
    source2 = requests.get(lhtml,headers={'user-agent':'Mozilla/5.0','referer':'https://www.janjua.tv/hembedplayer/'+chName+'/3/800/456','accept':'*/*'}).content
    if PY3:
        source2 = source2.decode('utf-8')
    m3u8 = 'https://'+re.findall('=(.*)',source2)[0]+':8088/live/'+chName+'/playlist.m3u8?id=%s&pk=%s'%(ids,tok)
    return m3u8

def rocktalk(parIn=None):
    from base64 import b64encode, b64decode
    from binascii import a2b_hex
    from Cryptodome.Cipher import PKCS1_v1_5 as Cipher_PKCS1_v1_5
    from Cryptodome.Cipher import DES
    from Cryptodome.PublicKey import RSA
    from Cryptodome.Util.Padding import unpad

    user_agent = 'USER-AGENT-tvtap-APP-V2'
    headers = {
        'User-Agent': user_agent,
        'app-token': '37a6259cc0c1dae299a7866489dff0bd',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Host': 'taptube.net',
	}
    
    _pubkey2 = RSA.importKey(
        a2b_hex(
            "30819f300d06092a864886f70d010101050003818d003081890281"
            "8100bfa5514aa0550688ffde568fd95ac9130fcdd8825bdecc46f1"
            "8f6c6b440c3685cc52ca03111509e262dba482d80e977a938493ae"
            "aa716818efe41b84e71a0d84cc64ad902e46dbea2ec61071958826"
            "4093e20afc589685c08f2d2ae70310b92c04f9b4c27d79c8b5dbb9"
            "bd8f2003ab6a251d25f40df08b1c1588a4380a1ce8030203010001"
        )
    )
    _msg2 = a2b_hex(
        "7b224d4435223a22695757786f45684237686167747948392b58563052513d3d5c6e222c22534"
        "84131223a2242577761737941713841327678435c2f5450594a74434a4a544a66593d5c6e227d"
    )
    cipher = Cipher_PKCS1_v1_5.new(_pubkey2)	
    tkn2 =  b64encode(cipher.encrypt(_msg2))
    ch_id = parIn
    r2 = requests.post('https://rocktalk.net/tv/index.php?case=get_channel_link_with_token_latest', 
        headers=headers,
        data={"payload": tkn2, "channel_id": ch_id, "username": "603803577"},
        timeout=15)

    from pyDes import des, PAD_PKCS5
    key = b"98221122"
    links = []
    jch = r2.json()["msg"]["channel"][0]
    for stream in jch.keys():
        if "stream" in stream or "chrome_cast" in stream:
            d = des(key)
            link = d.decrypt(b64decode(jch[stream]), padmode=PAD_PKCS5)
            if link:
                link = link.decode("utf-8")
                if not link == "dummytext" and link not in links:
                    links.append((link, ""))

    return links



def myStream(parIn=None):
    video_urls = []
    page_url = "https://embed.mystream.to/"+parIn
    logging.warning('CALL: '+page_url)
    page_data = requests.get(page_url,headers={'user-agent':'Mozilla/5.0','accept':'*/*'}).content
    if PY3:
        page_data = page_data.decode('utf-8')
    page_decode = decodeMyStream(page_data)
    video_url = preg_match(page_decode, r"'src',\s*'([^']+)")
    logging.warning('video_url '+video_url)
    video_urls.append((video_url, ""))
    return video_urls


def decodeMyStream(data):
    # adapted from MyStream.py code - https://github.com/kodiondemand/addon/blob/master/servers/mystream.py
    first_group = preg_match(data, r'"\\"("\+.*?)"\\""\)\(\)\)\(\)')
    match = preg_match(first_group, r"(\(!\[\]\+\"\"\)\[.+?\]\+)")
    if match:
        first_group = first_group.replace(match, 'l').replace('$.__+', 't').replace('$._+', 'u').replace('$._$+', 'o')

        tmplist = []
        js = preg_match(data, r'(\$={.+?});')
        if js:
            js_group = js[3:][:-1]
            second_group = js_group.split(',')

            i = -1
            for x in second_group:
                a, b = x.split(':')

                if b == '++$':
                    i += 1
                    tmplist.append(("$.{}+".format(a), i))

                elif b == '(![]+"")[$]':
                    tmplist.append(("$.{}+".format(a), 'false'[i]))

                elif b == '({}+"")[$]':
                    tmplist.append(("$.{}+".format(a), '[object Object]'[i]))

                elif b == '($[$]+"")[$]':
                    tmplist.append(("$.{}+".format(a), 'undefined'[i]))

                elif b == '(!""+"")[$]':
                    tmplist.append(("$.{}+".format(a), 'true'[i]))

            tmplist = sorted(tmplist, key=lambda z: str(z[1]))
            for x in tmplist:
                first_group = first_group.replace(x[0], str(x[1]))

            first_group = first_group.replace('\\"', '\\').replace("\"\\\\\\\\\"", "\\\\").replace('\\"', '\\').replace('"', '').replace("+", "")
    return first_group.encode('ascii').decode('unicode-escape').encode('ascii').decode('unicode-escape')

def preg_match(data, patron, index=0):
    try:
        if index == 0:
            matches = re.search(patron, data, flags=re.DOTALL)
            if matches:
                if len(matches.groups()) == 1:
                    return matches.group(1)
                elif len(matches.groups()) > 1:
                    return matches.groups()
                else:
                    return matches.group()
            else:
                return ""
        else:
            matches = re.findall(patron, data, flags=re.DOTALL)
            return matches[index]
    except:
        return ""


def run (action, params=None):
    logging.warning('Run version '+versione)
    commands = {
        'rsi': rsi,
        'myStream': myStream,
        'rocktalk': rocktalk
    }
    if action in commands:
        return commands[action](params)
    else:
        raise ValueError('Invalid command: {0}!'.action)