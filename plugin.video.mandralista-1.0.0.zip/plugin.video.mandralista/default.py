# -*- coding: utf-8 -*-
# ------------------------------------------------------------
# XBMC entry point
# ------------------------------------------------------------

import os
import sys
import re
import xbmc
import xbmcaddon
import xbmcgui
import logging


addon_id = 'plugin.video.mandralista'
selfAddon = xbmcaddon.Addon(id=addon_id)
debug = selfAddon.getSetting("debug")

PY3 = sys.version_info[0] == 3

def logga(mess):
    if debug == "on":
        logging.warning('MANDRA_LOG: '+mess)

def loggaErrore(mess):
    logging.warning('MANDRA_ERROR: '+mess)

def checkLauncher():
    import datetime
    home = ''
    if PY3:
        home = xbmc.translatePath(selfAddon.getAddonInfo('path'))
    else:
        home = xbmc.translatePath(selfAddon.getAddonInfo('path').decode('utf-8'))
    launcher_file = os.path.join(home, 'launcher.py')

    x = datetime.datetime.now()
    now =int(x.strftime("%Y")+x.strftime("%m")+x.strftime("%d")+x.strftime("%H")+x.strftime("%M"))
    lst =int(selfAddon.getSetting("lastUpd"))
    
    if (now - lst) > 60:
        resF = open(launcher_file)
        resolver_content = resF.read()
        resF.close()
        local_vers = re.findall("versione='(.*)'",resolver_content)[0]
        logga('local_vers '+local_vers)
        remote_vers = local_vers
        remoteLauncherUrl = selfAddon.getSetting("baseUrl")
        strSource = makeRequest(remoteLauncherUrl)
        if strSource is None or strSource == "":
            logga('We failed to get source from '+remoteLauncherUrl)
        else:
            if PY3:
                strSource = strSource.decode('utf-8')		
            remote_vers = re.findall("versione='(.*)'",strSource)[0]
        logga('remote_vers '+remote_vers)
        if local_vers != remote_vers:
            logga('TRY TO UPDATE VERSION')
            try:
                f = open(launcher_file, "w")
                f.write(strSource)
                f.close()
                msgBox('VERSION UPDATE TO '+remote_vers)
            except Exception as err:
                errMsg="ERRORE: {0}".format(err)
                loggaErrore('Error to update luncher\n'+errMsg)
                pass

def makeRequest(url, hdr=None):
    logga('Try to open '+url)
    html = ""
    if PY3:
	    import urllib.request as myRequest
    else:
	    import urllib2 as myRequest

    pwd = selfAddon.getSetting("password")
    version = selfAddon.getAddonInfo("version")
    if hdr is None:
        ua = "MandraLista@@"+version+"@@"+pwd
        hdr = {"User-Agent" : ua}
    try:
        req = myRequest.Request(url, headers=hdr)
        response = myRequest.urlopen(req)
        html = response.read()
        response.close()
    except:
        loggaErrore('Error to open url')
        pass
    return html

def msgBox(mess):
    dialog = xbmcgui.Dialog()
    dialog.ok("MandraLista", mess)


try:
    import launcher
    if sys.argv[2] == "":
        logga("=== OPEN ADDON ===")
        checkLauncher()

    logga("PAR - "+sys.argv[2])
    launcher.run()
except Exception as err:
    import traceback
    errMsg="ERRORE: {0}".format(err)
    logging.warning(errMsg+"\nPAR_ERR --> "+sys.argv[2])
    traceback.print_exc()
    msgBox("Accidenti!\nSembra esserci qualche errore non gestito.\nSe il problema persiste, prova ad inviare il log.")
   